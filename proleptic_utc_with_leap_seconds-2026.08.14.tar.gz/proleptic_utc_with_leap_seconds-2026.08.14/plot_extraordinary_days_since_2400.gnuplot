set encoding utf8
set minussign
set style data steps
set grid xtics
set grid ytics
set xtics rotate by 90
set xtics right
set title "Values of DTAI 2400 to 2410"
set xlabel "Date" offset 0,-1
set ylabel "DTAI"
set format y "\\num[mode=text]{%g}"
set xrange [2597641:2601294]
set yrange [530:570]
load "./set_xtics_001yr.gnuplot"
set nokey
set xtic rotate by 45
set terminal lua tikz size 12,7
set output "values_of_DTAI_since_2400.tex"
plot 'gnuplot.dat' using 1:2


