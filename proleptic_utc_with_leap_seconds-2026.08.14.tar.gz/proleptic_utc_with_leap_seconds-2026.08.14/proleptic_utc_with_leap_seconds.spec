Name:           proleptic_utc_with_leap_seconds
Version:        2026.08.14
Release:        1%{?dist}
Summary:        Schedule leap seconds

License:        GPL-3.0-or-later AND CC-BY-SA-4.0
URL:            https://github.com/ShowControl/proleptic_UTC_with_leap_seconds
Source0:        https://github.com/ShowControl/proleptic_utc_with_leap_seconds/blob/master/proleptic_utc_with_leap_seconds-%{version}.tar.gz
                
BuildArch: noarch

BuildRequires:  gcc
BuildRequires:  make
BuildRequires:  python3 >= 3.13
BuildRequires:  git
BuildRequires:  python3-jdcal
BuildRequires:  python3-numpy
BuildRequires:  python3-scipy
BuildRequires:  python3-pandas

%description
Schedule leap seconds in the distant past and far future
based on historical astronomical observations and
information from the International Earth Rotation System Service (IERS).

%prep
%autosetup -S git

%build

# Tell configure to rebuild the PDF file
%configure --enable-pdf

%make_build

%install
%make_install

%check
make check VERBOSE=1

%package devel
Summary: Schedule leap seconds in the distant past and far future
Requires: %{name} = %{version}-%{release}

%description devel
The %{name}-devel package
contains the man file for %{name}.

%package doc
Summary: Comprehensive documentation for %{name}
Requires: %{name} = %{version}-%{release}

# gnuplot and texlive-scheme-full are needed to rebuild the PDF file.
# The PDF may use the Andika, Charis and Liberation Mono fonts.
BuildRequires: gnuplot
BuildRequires: texlive-scheme-full
BuildRequires: sil-andika-fonts
BuildRequires: sil-charis-fonts
BuildRequires: liberation-mono-fonts

%description doc
The %{name}-doc package contains the documentation
for %{name}
in the form of a PDF file which describes why it is useful to schedule
leap seconds in the distant past and the far future
and presents some of the results.
Included in the PDF file using embedding are all of the
files and instructions needed to create the source tarball, which
includes the RPM spec file.

%files
%defattr(-,root,root)
%exclude /usr/share/doc/%{name}/AUTHORS
%exclude /usr/share/doc/%{name}/COPYING
%exclude /usr/share/doc/%{name}/ChangeLog
%exclude /usr/share/doc/%{name}/INSTALL
%exclude /usr/share/doc/%{name}/NEWS
%exclude /usr/share/doc/%{name}/README
%exclude /usr/share/doc/%{name}/LICENSE
%exclude /usr/share/doc/%{name}/proleptic_UTC.pdf
%{_datadir}/%{name}/data/extraordinary_days.dat
%license LICENSE
%license COPYING

%files devel
%defattr(-,root,root)
%{_mandir}/man5/extraordinary_days.dat.5.*
%doc AUTHORS ChangeLog NEWS README
%license LICENSE
%license COPYING

%files doc
%defattr(-,root,root)
%doc proleptic_UTC.pdf
%doc AUTHORS ChangeLog NEWS README
%license LICENSE
%license COPYING

%changelog
 * Fri Aug 14 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.08.14-1 Adjust future leap seconds starting in 2045.
 * Fri Aug 07 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.08.07-1 Adjust future leap seconds starting in 2046.
 * Fri Jul 31 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.07.31-1 Adjust future leap seconds starting in 2069.
 * Fri Jul 24 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.07.24-1 Adjust future leap seconds starting in 2047.
 * Fri Jul 17 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.07.17-1 Adjust future leap seconds starting in 2083.
 * Fri Jul 10 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.07.10-1 Adjust future leap seconds starting in 2061.
 * Fri Jul 03 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.07.03-1 Adjust future leap seconds starting in 2065.
 * Fri Jun 26 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.06.26-1 Adjust future leap seconds starting in 2085.
 * Fri Jun 19 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.06.19-1 Adjust future leap seconds starting in 2052.
 * Fri Jun 12 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.06.12-1 Adjust future leap seconds starting in 2068.
 * Fri Jun 05 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.06.05-1 Adjust future leap seconds starting in 2072.
 * Fri May 29 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.05.29-1 Adjust future leap seconds starting in 2064.
 * Fri May 22 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.05.22-1 Adjust future leap seconds starting in 2060.
 * Fri May 15 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.05.15-1 Adjust future leap seconds starting in 2078.
 * Fri May 01 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.05.01-1 Adjust future leap seconds starting in 2068.
 * Fri Apr 17 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.04.17-1 Adjust future leap seconds starting in 2189.
 * Fri Apr 10 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.04.10-1 Adjust future leap seconds starting in 2071.
 * Fri Mar 20 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.03.20-1 Adjust future leap seconds starting in 2095.
 * Fri Feb 13 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.02.13-1 Adjust future leap seconds starting in 2090.
 * Fri Jan 23 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.01.23-1 Adjust future leap seconds starting in 2031.
 * Fri Jan 16 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.01.16-1 Adjust future leap seconds starting in 2149.
 * Fri Jan 02 2026 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2026.01.02-1 Adjust future leap seconds starting in 2030.
 * Fri Nov 28 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.11.28-1 Adjust future leap seconds starting in 2030.
 * Fri Oct 31 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.10.31-1 Adjust future leap seconds starting in 2067.
 * Fri Sep 19 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.09.19-1 Adjust future leap seconds starting in 2161.
 * Fri Aug 22 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.08.22-1 Adjust future leap seconds starting in 2099.
 * Fri Aug 15 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.08.15-1 Adjust future leap seconds starting in 2029.
 * Fri Jul 25 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.07.25-1 Adjust future leap seconds starting in 2047.
 * Fri Jul 18 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.07.18-1 Adjust future leap seconds starting in 2051.
 * Fri Jul 11 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.07.11-1 Adjust future leap seconds starting in 2224.
 * Fri Jul 04 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.07.04-1 Adjust future leap seconds starting in 2150.
 * Fri Jun 13 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.06.13-1 Adjust future leap seconds starting in 2080.
 * Fri Jun 06 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.06.06-1 Adjust future leap seconds starting in 2194.
 * Fri May 30 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.05.30-1 Adjust future leap seconds starting in 2029.
 * Fri May 23 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.05.05-1 Adjust future leap seconds starting in 2208.
 * Fri Apr 04 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.04.04-1 Adjust future leap seconds starting in 2063.
 * Fri Feb 21 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.02.21-1 Adjust future leap seconds starting in 2063.
 * Fri Jan 10 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.01.10-1 Adjust future leap seconds starting in 2274.
 * Fri Jan 03 2025 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2025.01.03-1 Adjust future leap seconds starting in 2223.
 * Fri Dec 27 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.12.27-1 Adjust future leap seconds starting in 2141.
 * Fri Dec 20 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.12.20-1 Adjust future leap seconds starting in 2097.
 * Fri Nov 01 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.11.01-1 Adjust future leap seconds starting in 2095.
 * Fri Sep 27 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.09.27-1 Adjust future leap seconds starting in 2142.
 * Fri Sep 06 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.09.06-1 Adjust future leap seconds starting in 2249.
 * Fri Aug 09 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.08.09-1 Adjust future leap seconds starting in 2249.
 * Fri Aug 02 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.08.02-1 Adjust future leap seconds starting in 2080.
 * Fri Jul 26 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.07.26-1 Adjust future leap seconds starting in 2275.
 * Fri Jul 19 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.07.19-1 Adjust future leap seconds starting in 2224.
 * Fri Jul 05 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.07.05-1 Adjust future leap seconds starting in 2051.
 * Fri Jun 28 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.06.28-1 Adjust future leap seconds starting in 2332.
 * Fri Jun 07 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.06.07-1 Adjust future leap seconds starting in 2372.
 * Fri May 31 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.05.31-1 Adjust future leap seconds starting in 2332.
 * Fri May 24 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.05.24-1 Adjust future leap seconds starting in 2218.
 * Fri May 17 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.05.17-1 Adjust future leap seconds starting in 2191.
 * Fri May 10 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.05.10-1 Adjust future leap seconds starting in 2047.
 * Fri Apr 26 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.04.26-1 Adjust future leap seconds starting in 2067.
 * Fri Apr 12 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.04.12-1 Adjust future leap seconds starting in 2029.
 * Fri Apr 05 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.04.05-1 Adjust future leap seconds starting in 2095.
 * Fri Mar 22 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.03.22-1 Adjust future leap seconds starting in 2278.
 * Fri Mar 15 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.03.15-1 Adjust future leap seconds starting in 2081.
 * Fri Mar 01 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.03.01-1 Adjust future leap seconds starting in 2235.
 * Fri Feb 23 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.02.23-1 Adjust future leap seconds starting in 2029.
 * Fri Feb 16 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.02.16-1 Adjust three future leap seconds starting in 2029.
 * Fri Feb 09 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.02.09-1 Adjust future leap seconds starting in 2405.
 * Fri Feb 02 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.02.02-1 Adjust future leap seconds starting in 2213.
 * Fri Jan 26 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.01.26-1 Adjust future leap seconds starting in 2211.
 * Fri Jan 19 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.01.19-1 Adjust future leap seconds starting in 2185.
 * Fri Jan 12 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.01.12-1 Adjust future leap seconds starting in 2308.
 * Fri Jan 05 2024 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2024.01.05-1 Adjust future leap seconds starting in 2308.
 * Fri Dec 29 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.12.29-1 Adjust future leap seconds starting in 2189.
 * Fri Dec 22 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.12.22-1 Adjust future leap seconds starting in 2140.
 * Fri Dec 15 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.12.15-1 Adjust future leap seconds starting in 2170.
 * Fri Dec 08 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.12.08-1 Adjust future leap seconds starting in 2199.
 * Fri Dec 08 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.12.08-1 Adjust future leap seconds starting in 2199.
 * Fri Dec 01 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.12.01-1 Adjust future leap seconds starting in 2140.
 * Sat Nov 25 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.11.25-1 Adjust future leap seconds starting in 2189.
 * Fri Nov 17 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.11.17-1 Adjust future leap seconds starting in 2056.
 * Fri Nov 03 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.11.03-2 correct an oversight in the PDF file.
 * Fri Nov 03 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.11.03-1 Adjust future leap seconds starting in 2081.
 * Sun Oct 29 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.10.29-1 Adjust future leap seconds starting in 2060.
 * Fri Oct 27 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.10.27-1 Adjust future leap seconds starting in 2439.
 * Fri Oct 20 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.10.20-1 Adjust future leap seconds starting in 2029.
 * Fri Oct 13 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.10.13-1 Adjust future leap seconds starting in 2400.
 * Sat Oct 07 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.10.07-2 Remove support for not rebuilding the documentation.
 * Sat Oct 07 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.10.07-1 Adjust future leap seconds starting in 2029.
 * Fri Sep 29 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.09.29-1 Adjust future leap seconds starting in 2029.
 * Fri Sep 22 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.09.22-1 Adjust future leap seconds starting in 2029.
 * Fri Sep 15 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.09.15-1 Adjust future leap seconds starting in 2034.
 * Fri Sep 08 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.09.08-1 Adjust future leap seconds starting in 2419.
 * Fri Sep 01 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.09.01-1 Adjust future leap seconds starting in 2419.
 * Fri Aug 18 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.08.18-1 Adjust future leap seconds starting in 2132.
 * Fri Aug 11 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.08.11-1 Adjust future leap seconds starting in 2407.
 * Fri Aug 04 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.08.04-1 Adjust future leap seconds starting in 2034.
 * Fri Jul 28 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.07.28-1 Adjust future leap seconds starting in 2271.
 * Fri Jul 21 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.07.21-1 Adjust future leap seconds starting in 2033.
 * Fri Jul 14 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.07.14-1 Adjust future leap seconds starting in 2167.
 * Fri Jul 07 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.07.07-1 Adjust future leap seconds starting in 2082.
 * Fri Jun 30 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.06.30-1 Adjust future leap seconds starting in 2328.
 * Fri Jun 23 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.06.23-1 Adjust future leap seconds starting in 2033.
 * Fri Jun 16 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.06.16-1 Adjust future leap seconds starting in 2067.
 * Fri Jun 09 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.06.09-1 Adjust future leap seconds starting in 2172.
 * Fri Jun 02 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.06.02-1 Adjust future leap seconds starting in 2032.
 * Fri May 26 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.05.26-1 Adjust future leap seconds starting in 2032.
 * Fri May 19 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.05.19-1 Adjust future leap seconds starting in 2184.
 * Fri May 12 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.05.12-1 Adjust future leap seconds starting in 2031.
 * Fri May 05 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.05.05-1 Adjust future leap seconds starting in 2031.
 * Fri Apr 28 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.04.28-1 Adjust future leap seconds starting in 2119.
 * Fri Apr 21 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.04.21-1 Adjust future leap seconds starting in 2119.
 * Fri Apr 14 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.04.14-1 Adjust future leap seconds starting in 2120.
 * Fri Apr 07 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.04.07-1 Adjust future leap seconds starting in 2030.
 * Fri Mar 31 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.03.31-1 Adjust future leap seconds starting in 2117.
 * Fri Mar 24 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.03.24-1 Adjust future leap seconds starting in 2093.
 * Fri Mar 17 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.03.17-1 Adjust future leap seconds starting in 2063.
 * Fri Mar 10 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.03.10-1 Adjust future leap seconds starting in 2122.
 * Fri Mar 03 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.03.03-1 Adjust future leap seconds starting in 2030.
 * Fri Feb 24 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.02.24-1 Adjust future leap seconds starting in 2098.
 * Fri Feb 17 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.02.17-1 Adjust future leap seconds starting in 2190.
 * Fri Feb 10 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.02.10-1 Adjust future leap seconds starting in 2029.
 * Fri Feb 03 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.02.03-1 Adjust future leap seconds starting in 2229.
 * Fri Jan 27 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.01.27-1 Adjust future leap seconds starting in 2063.
 * Fri Jan 13 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.01.13-1 Adjust future leap seconds starting in 2029.
 * Fri Jan 06 2023 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2023.01.06-1 Adjust future leap seconds starting in 2038.
 * Fri Dec 30 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.12.30-1 Adjust future leap seconds starting in 2169.
 * Fri Dec 23 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.12.23-1 Adjust future leap seconds starting in 2028.
 * Fri Dec 16 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.12.16-1 Adjust future leap seconds starting in 2214.
 * Fri Dec 09 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.12.09-1 Adjust future leap seconds starting in 2037.
 * Fri Dec 02 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.12.02-1 Adjust future leap seconds starting in 2256.
 * Fri Nov 25 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.11.25-1 Adjust future leap seconds starting in 2069.
 * Fri Nov 18 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.11.18-1 Adjust future leap seconds starting in 2069.
 * Fri Nov 11 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.11.11-1 Adjust future leap seconds starting in 2028.
 * Fri Nov 04 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.11.04-1 Adjust future leap seconds starting in 2197.
 * Fri Oct 28 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.10.28-1 Adjust future leap seconds starting in 2036.
 * Fri Oct 21 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.10.21-1 Adjust future leap seconds starting in 2108.
 * Fri Oct 14 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.10.14-1 Adjust future leap seconds starting in 2027.
 * Fri Sep 16 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.09.16-1 Adjust future leap seconds starting in 2027.
 * Fri Sep 09 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.09.09-1 Adjust future leap seconds starting in 2135.
 * Fri Aug 12 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.08.12-1 Adjust future leap seconds starting in 2064.
 * Fri Aug 05 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.08.05-1 Adjust future leap seconds starting in 2064.
 * Fri Jul 22 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.07.22-1 Adjust future leap seconds starting in 2036.
 * Fri Jul 08 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.07.08-1 Adjust future leap seconds starting in 2036.
 * Fri Jul 01 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.07.01-1 Adjust future leap seconds starting in 2028.
 * Fri Jun 10 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.06.10-1 Adjust future leap seconds starting in 2037.
 * Fri May 27 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.05.27-1 Adjust future leap seconds starting in 2028.
 * Fri May 13 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.05.13-1 Adjust future leap seconds starting in 2028.
 * Fri May 06 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.05.06-1 Adjust future leap seconds starting in 2028.
 * Fri Apr 29 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.04.29-1 Adjust future leap seconds starting in 2038.
 * Fri Apr 15 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.04.15-1 Adjust future leap seconds starting in 2029.
 * Fri Apr 01 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.04.01-1 Adjust future leap seconds starting in 2029.
 * Fri Mar 18 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.03.18-1 Adjust future leap seconds starting in 2030.
 * Fri Mar 11 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.03.11-1 Adjust future leap seconds starting in 2062.
 * Fri Feb 25 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.02.25-1 Adjust future leap seconds starting in 2030.
 * Sat Feb 19 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.02.19-1 Adjust future leap seconds starting in 2068.
 * Fri Feb 18 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.02.18-1 Adjust future leap seconds starting in 2141.
 * Fri Jan 07 2022 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2022.01.07-1 Adjust future leap seconds starting in 2155.
 * Fri Dec 10 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.12.10-1 Adjust future leap seconds starting in 2030.
 * Fri Nov 19 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.11.19-1 Adjust future leap seconds starting in 2030.
 * Fri Nov 12 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.11.12-1 Adjust future leap seconds starting in 2030.
 * Fri Oct 29 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.10.29-1 Adjust future leap seconds starting in 2068.
 * Fri Oct 15 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.10.15-1 Adjust future leap seconds starting in 2062.
 * Fri Sep 24 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.09.24-1 Adjust future leap seconds starting in 2062.
 * Fri Sep 10 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.09.10-1 Adjust future leap seconds starting in 2072.
 * Fri Aug 20 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.08.20-1 Adjust future leap seconds starting in 2030.
 * Fri Jul 30 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.07.30-1 Adjust future leap seconds starting in 2076.
 * Fri Jul 23 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.07.23-1 Adjust future leap seconds starting in 2029.
 * Fri Jul 09 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.07.09-1 Adjust future leap seconds starting in 2412.
 * Fri Jul 02 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.07.02-1 Adjust future leap seconds starting in 2088.
 * Fri Jun 25 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.06.25-1 Adjust future leap seconds starting in 2091.
 * Fri Jun 18 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.06.18-1 Adjust future leap seconds starting in 2353.
 * Fri Jun 11 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.06.11-1 Adjust future leap seconds starting in 2287.
 * Fri Jun 04 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.06.04-1 Adjust future leap seconds starting in 2063.
 * Sun May 30 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.05.28-4 Build PDF file, but only if TeX is available.
 * Sat May 29 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.05.28-2 Allow for a future change to the man file compression method.
 * Fri May 28 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.05.28-1 Adjust future leap seconds starting in 2182.
 * Fri May 21 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.05.21-1 Adjust future leap seconds starting in 2029.
 * Fri May 14 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.05.14-1 Adjust future leap seconds starting in 2073.
 * Fri May 07 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.05.07-1 Adjust future leap seconds starting in 2357.
 * Fri Apr 23 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.04.23-1 Adjust future leap seconds starting in 2029.
 * Fri Apr 16 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.04.16-1 Adjust future leap seconds starting in 2245.
 * Fri Apr 09 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.04.09-1 Adjust future leap seconds starting in 2063.
 * Fri Apr 02 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.04.02-1 Adjust future leap seconds starting in 2029.
 * Fri Mar 26 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.03.26-1 Adjust future leap seconds starting in 2030.
 * Fri Mar 19 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.03.19-1 Adjust future leap seconds starting in 2068.
 * Fri Mar 12 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.03.12-1 Adjust future leap seconds starting in 2030.
 * Fri Mar 05 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.03.05-1 Include the latest research on historical values of delta T.
 * Fri Feb 26 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.02.26-1 Adjust future leap seconds starting in 2104.
 * Fri Feb 19 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.02.19-1 Adjust future leap seconds starting in 2051.
 * Fri Feb 12 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.02.12-1 Adjust future leap seconds starting in 2103.
 * Fri Feb 05 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.02.05-1 Adjust future leap seconds starting in 2055.
 * Fri Jan 29 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.01.29-1 Adjust future leap seconds starting in 2089.
 * Fri Jan 22 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.01.22-1 Adjust future leap seconds starting in 2070.
 * Fri Jan 15 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.01.15-1 Adjust future leap seconds starting in 2039.
 * Fri Jan 08 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.01.08-1 There will be no leap second in June 2021.
 - Adjust future leap seconds starting in 2105.
 * Fri Jan 01 2021 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2021.01.01-1 Adjust future leap seconds starting in 2064.
 * Fri Dec 25 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.12.25-1 Adjust future leap seconds starting in 2077.
 * Fri Dec 18 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.12.18-1 Adjust future leap seconds starting in 2044.
 * Fri Dec 04 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.12.04-1 Adjust future leap seconds starting in 2070.
 * Fri Nov 27 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.11.27-1 Adjust future leap seconds starting in 2097.
 * Fri Nov 20 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.11.20-1 Adjust future leap seconds starting in 2067.
 * Fri Nov 13 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.11.13-1 Delay the December 2093 leap second by six months to June 2094.
 * Fri Nov 06 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.11.06-1 Adjust future leap seconds starting in 2033.
 * Fri Oct 30 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.10.30-1 Adjust future leap seconds starting in 2033.
 * Fri Oct 23 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.10.23-1 Adjust future leap seconds starting in 2033.
 * Fri Oct 16 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.10.16-1 Adjust future leap seconds starting in 2062.
 * Fri Oct 02 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.10.02-1 Adjust future leap seconds starting in 2059.
 * Fri Sep 25 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.09.25-1 Adjust almost all future leap seconds starting in 2032.
 * Fri Sep 04 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.09.04-1 Adjust almost all future leap seconds.
 * Fri Aug 28 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.08.28-1 Adjust future leap seconds starting in 2089.
 * Fri Aug 21 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.08.21-1 Adjust future leap seconds starting in 2031.
 * Fri Aug 14 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.08.14-1 Adjust future leap seconds starting in 2073.
 * Fri Aug 07 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.08.07-1 Adjust future leap seconds starting in 2114.
 * Fri Jul 31 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.07.31-1 Adjust future leap seconds starting in 2120.
 * Fri Jul 24 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.07.24-1 Adjust future leap seconds starting in 2055.
 * Wed Jul 22 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.07.17-9 Provide NEWS, etc. files.
 * Fri Jul 17 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.07.17-1 Adjust future leap seconds starting in 2080.
 * Fri Jul 10 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.07.10-1 Update to IERS Bulletin C 60.
                Adjust many future leap seconds starting in 2066.
 * Fri Jul 03 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.07.03-1 Adjust many future leap seconds starting in 2025.
 * Fri Jun 26 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.06.26-1 Adjust many future leap seconds starting in 2068.
 * Fri Jun 19 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.06.19-1 Adjust many future leap seconds starting in 2063.
 * Fri Jun 12 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.06.12-1 Adjust many future leap seconds starting in 2098.
 * Fri Jun 05 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.06.05-1 Adjust many future leap seconds starting in 2087.
 * Fri May 29 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.05.29-1 Adjust many future leap seconds starting in 2106.
 * Thu May 21 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.05.21-1 Adjust several distant future leap seconds.
 * Thu May 14 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.05.14-1 Adjust five distant future leap seconds.
 * Thu May 07 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.05.07-1 Adjust five distant future leap seconds.
 * Thu Apr 30 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
 - 2020.04.30-1 Convert the PDF to the Libertine font and adjust several
   far future leap seconds.
 * Fri Apr 24 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.04.24-1 Embed the missing files in the PDF.
 * Thu Apr 23 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.04.23-1 Advance three far future leap seconds by three or six months.
 * Sat Apr 18 2020 John Sauter <John_Sauter@systemeyescomputerstore.com>
- 2020.04.18-1 Initial version of the spec file.
