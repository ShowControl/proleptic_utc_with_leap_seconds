set encoding utf8
set minussign
set style data steps
set grid xtics
set grid ytics
set xtics rotate by 90
set xtics right
set title "Values of DTAI"
set xlabel "Date" offset 0,-1
set ylabel "DTAI"
set format y "\\num[mode=text]{%g}"
set xrange [*:4277757]
load "./set_xtics_500yr.gnuplot"
set nokey
set xtic rotate by 45
set terminal lua tikz size 12,7 latex createstyle
set output "values_of_DTAI.tex"
plot 'gnuplot.dat' using 1:2
